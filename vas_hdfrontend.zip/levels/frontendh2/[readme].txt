
                            ---------------------
                            HOOD FRONTEND: AUTUMN
                            ---------------------
								
                                 R E A D M E
                        Version 1.1, from May 1st 2021

  S U M M A R Y
═════════════════════════════════════════════════════════════════════════════
Track Name:     Hood Frontend: Autumn
Folder Name:    frontendh2
Author:         Kiwi
Creation:       October 2020


  D E S C R I P T I O N
═════════════════════════════════════════════════════════════════════════════
This is the autumn version of the Hood Frontend. The Hood Frontend was the 
very first fully functional custom frontend for Re-Volt, using all the
possibilities RVGL introduced for frontend customation in the last years.
Navigate the main menu through the iconic Toys in the Hood starting area, in
the modern version I initially made for the use in my track "School's Out!".

Installation: 

Just install the frontend like you do with normal custom tracks: Copy the
downloaded files in your RVGL directory. After restarting RVGL, you have a
new menu-entry in options named "Frontend". Here you can switch to the Hood
Frontends. You can switch back to the Default Frontend whenever you like.

Major features of the Hood Frontend:

+ Stock-like design pared with modern graphics (shadows, lot of details,...)
+ Completly functional (Name wheel, car preview, trophy ceremony,...)
+ New frontend music track
+ You can choose between a PC- and a DC- box layout
+ Support for RVGL's new Diamond Cup feature

Winter-, and spring-editions of the frontend will come later. :)

Have fun!
  Kiwi
  
  
  B O X   L A Y O U T S
═════════════════════════════════════════════════════════════════════════════
The standard layout of the car-stack in the car selection screen includes 
boxes for the cars from the DC-pack (Splat, JG-7, RV Loco,...). If you would 
like to switch to the PC box-layout, you have to do the following:

(1) Browse to the tracks directory (../levels/frontendh2)
(2) Browse to the "/extra" directory
(3) Browse either to the "DC Box Layout" or the "PC Box Layout" directory
(3) Copy the frontendh2.fob of your choice to the tracks main directory. (1)

You can go back to the other box layout anytime by following the steps again.


  C O M P A T I B I L I T Y
═════════════════════════════════════════════════════════════════════════════
+ This frontend is only compatible with RVGL 19.0120a or later. It's not
  compatible with the original (Vanilla) Re-Volt or Re-Volt 1.2.
+ For best performance and increased graphic quality, it's highly recommended
  to use the shader renderer. Set 'shaders = 1' in 'rvgl\profiles\rvgl.ini' 
  where 'rvgl' is the location of your RVGL installation.


  K N O W N    I S S U E S
═════════════════════════════════════════════════════════════════════════════
+ Issues when not using the shader renderer: A much higher chance to get
  framedrops; general graphical issues - especially flickering translucent
  faces and lights.
+ Not intended menu screen positions when using a custom FOV setting.


  C R E A T I O N
═════════════════════════════════════════════════════════════════════════════
Used Tools:     + Blender 2.79b with Marv's Re-Volt Plugin
                + Ulead Photo Impact 12a
                + World Cut 11-11-11 by jigebren
                + Audacity 2.2.2
                + Notepad++ v7.8.7
                + RVGL Makeitgood modeb
				 
W Polys:        ~ 28.000
NCP Polys:      ~     90

I used some meshes and textures from other tracks as a basis, and adjusted
them so they fitted my needs. They are listed below. Meshes and textures
which are not listed are made by me from scratch or are modified versions 
from free sources on the internet. Re-used models from the original Re-Volt 
tracks (made by Probe/Acclaim) are also not listed.

Used meshes:    + Detached Dust Mite (Base): Skating Toys Redux by Zorbah
                + Waste bag: Grisville by Allan1
				+ Pumpkin: Spooky-Volt by Xarc
				+ Diamond Cup: Trixed

Used textures:  + Detached Dust Mite (Base): Skating Toys Redux by Zorbah
                + Waste bag: Grisville by Allan1
				+ Garage cupboards: ToySoldierz by Skitch
				+ Pemto carbox: RV_Passion
				+ Pumpkin: Spooky-Volt by Xarc

Used Music:

"Luna Lena" (Original Mix) by Boris Brechja (c) 2017
Hood-Remix (c) 2020 by Kiwi

For You, For Everybody, For Free
https://www.borisbrejcha.de/downloads


  T H A N K    Y O U
═════════════════════════════════════════════════════════════════════════════
Thank you to the original Probe developers for creating Re-Volt, and thank
you to Huki & the rest of the RVGL team for keeping the game alive more than
20 years after its initial release.

Thank you to the great Re-Volt community, for inspiring and motivating
me. Also a big thanks to the ladies and gentlemen at the Discord's #tracks
channel, for your comments, ideas and suggestions.

Thanks to Gabor Varga, whose tracks inspired me a lot to also do stock-like
content for Re-Volt.

Greetings to my wife Bianca.

                     ----------------------------
                V E R Y   S P E C I A L    T H A N K S
                     ----------------------------

+ Trixed			For the Diamond Cup mesh
+ Mighty Cucumber 	For betatesting and doing some mesh-optimizations
+ Matsilagi			For betatesting and providing textures
+ Zorbah			For his Dust Mite base assets
+ Geromu Keretem	For the music hint
+ Gotolei			For doing the School's Out! shading, which I reused here


  R E L E A S E   H I S T O R Y
═════════════════════════════════════════════════════════════════════════════
Version 1.1 from May 1st 2021
 + Added support for RVGL's new Diamond Cup feature
Version 1.0 from October 5th 2020
 + Initial public release, released on garage.re-volt.io

 
  D I S C L A I M E R
═════════════════════════════════════════════════════════════════════════════
You are free to distribute this frontend, but please don't change any parts
of it without my approval. Contact me on Discord or at TRH forum.

You are free to use parts of the frontend (models, textures, sounds, ...)
for your own purposes, but don't forget to credit the original authors.