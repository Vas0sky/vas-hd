
Toy World Frontend
Version 1.4 from 6. January 2021

Created by:		Jan Aínnír Mayen
Created:		04. December 2020

Length:			N/A
Difficulty:		N/A
Time trial:		N/A
Practice star:	N/A
Foldername:		frontendtoy

Vis. Polygons:	~ 6.500
Col. Polygons:	~ 1.600

____________________________________________________

Description:

Frontend located at the Toy World scenario.
Including custom cup trophy made by Trixed.

Included also a custom cup - "Sprint Cup"!

You need the following tracks to play this cup:

- Grisville
- Jailhouse Rock
- Quake!
- Rooftops 1
- School's Out! 1
- School's Out! 2
- The Great Silence
- Venice

...and at least 4 Super-Pro cars installed.

Best experience by choosing a good Semi-Pro car.
For more challenge, choose a weak Semi-Pro car, or
an Advanced rated car. You for sure can also choose
a Pro or a Super-Pro car, but then the cup maybe will
be too easy.

Have fun!

____________________________________________________

Developers:

Jan Aínnír Mayen

Acclaim:
- Original mesh
- Original textures

Trixed:
- Custom cup mesh

____________________________________________________

Thanks:

To whole Re-Volt Discord #tracks channel
Daiki Akaoni And Tubers for bug reports

____________________________________________________

